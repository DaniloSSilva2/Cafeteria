
 Aplicativo de Cafeteria Feito no Android Studio -
  Kotlin ![Captura de Tela (177)](https://github.com/user-attachments/assets/45b931c4-7f4e-4143-83c4-7e5d8a117334)
